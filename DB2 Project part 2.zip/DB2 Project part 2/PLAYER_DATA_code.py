from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client.FIFA
PLAYER_DATA = db.PLAYER_DATA

team_data = list(db['TEAM'].find())
teams = []
for team in team_data:
    teams.append([team['CId'], team['CName']])

player_data = list(db['PLAYER'].find())
players = []
for player in player_data:
    players.append([player['PNo'], player['CId'], player['PName'], player['PJName'], player['Position']])
    
stadiums = []
stadium_data = list(db['STADIUM'].find())
for stadium in stadium_data:
    stadiums.append([stadium['SId'], stadium['SName'], stadium['City']])
    
games = []
game_data = list(db['GAME'].find())
for game in game_data:
    games.append([game['GId'],game['GDate'], game['CId1'], game['Score1'], game['CId2'], game['Score2'], game['Venue']])
    
goals = []
goal_data = list(db['GOALS'].find())
for goal in goal_data:
    goals.append([goal['CId'], goal['GId'], goal['GoalType'], goal['Minute'], goal['PNo']])
    
lineups = []
starting_lineup_data = list(db['STARTING_LINEUP'].find())
for lineup in starting_lineup_data:
    lineups.append([lineup['GId'], lineup['CId'], lineup['PNo']])

PLAYER_DATA.remove({})

for game in games:
    for stadium in stadiums:
        if game[6] == stadium[0]:
            game.append(stadium[1])
            game.append(stadium[2])
            break

for goal in goals:
    for game in games:
        if goal[1] == game[0]:
            goal.append(game[1])
            goal.append(game[7])
            goal.append(game[8])

for player in players:
    document = {}
    document['Pname'] = player[2] 
    document['PNo'] = player[0]
    document['Position'] = player[4]
    for team in teams:
        if player[1] == team[0]:
            document['Team'] = team[1]
            break
    gameIds = []
    for lineup in lineups:
        if player[0] == lineup[2]:
            gameIds.append(lineup[0])
    gameList = []
    for game in games:
        gameDic = {}
        if game[0] in gameIds:
            gameDic['Match Date'] = game[1] 
            gameDic['City'] = game[8]
            gameDic['Stadium Name'] = game[7]
            oppTeamId = game[2] if game[2] != player[1] else game[4]
            for team in teams:
                if team[0] == oppTeamId:
                    gameDic['Opposing Team Name'] = team[1]
                    break
            gameList.append(gameDic)
    document['Collection Of Games'] = gameList
    goalList = []
    for goal in goals:
        goalDic = {}
        if player[0] == goal[4]:
            goalDic['Goal Type'] = goal[2]
            goalDic['Time'] = goal[3]
            goalDic['Match Date'] = goal[5]
            goalDic['City'] = goal[7]
            goalDic['Stadium Name'] = goal[6]
            for game in games:
                if goal[1] == game[0]:
                    oppTeamId = game[2] if game[2] != player[1] else game[4]
                    for team in teams:
                        if team[0] == oppTeamId:
                            goalDic['Opposing Team Name'] = team[1]
                            break
            goalList.append(goalDic)
    document['Collection of Goals'] = goalList
    id = PLAYER_DATA.insert(document)

