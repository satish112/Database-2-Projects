from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client.FIFA 
team_score = db.TEAM_SCORES 

team_data = list(db['TEAM'].find())
teams = []
for team in team_data:
    teams.append([team['CId'], team['CName']])
    
stadiums = []
stadium_data = list(db['STADIUM'].find())
for stadium in stadium_data:
    stadiums.append([stadium['SId'], stadium['SName'], stadium['City']])
    
games = []
game_data = list(db['GAME'].find())
for game in game_data:
    games.append([game['GDate'], game['CId1'], game['Score1'], game['CId2'], game['Score2'], game['Venue']])

team_score.remove({})

for game in games:
    for stadium in stadiums:
        if game[5] == stadium[0]:
            game.append(stadium[1])
            game.append(stadium[2])
            break
            
for game in games:
    for team in teams:
        if game[1] == team[0]:
            game.append(team[1])
            break
    for team in teams:
        if game[3] == team[0]:
            game.append(team[1])
            break

for team in teams:
    document = {}
    document['TeamName'] = team[1]
    matchList = []
    for game in games:
        gDic = {}
        if game[1] == team[0] or game[3] == team[0]:
            gDic['Match Date'] = game[0]
            gDic['Stadium Name'] = game[6]
            gDic['Stadium City'] = game[7]
            gDic['Team 1 Name'] = game[8]
            gDic['Team 1 Score'] = game[2]
            gDic['Team 2 Name'] = game[9]
            gDic['Team 2 Score'] = game[4]
            matchList.append(gDic)
    document['matches collection'] = matchList
    team_score.insert(document)